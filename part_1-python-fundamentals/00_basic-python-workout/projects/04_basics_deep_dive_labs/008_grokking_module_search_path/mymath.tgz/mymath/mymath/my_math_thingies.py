"""My math thingies module: where we define functions and constants related to math."""

_version = "0.1.0"

pi = 3.14159


def area(radius: float) -> float:
    """Calculate the area of a circle given its radius."""
    return pi * radius * radius


if __name__ == "__main__":
    print(f"My Math Thingies Module v{_version}")
    r = 5.0
    print(f"Area of a circle with radius {r}: {area(r)}")
